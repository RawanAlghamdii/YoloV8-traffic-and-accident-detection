# Car Crash Detection > 2022-12-03 11:33pm
https://universe.roboflow.com/mada-study/car-crash-detection-c9xlj

Provided by a Roboflow user
License: Public Domain

